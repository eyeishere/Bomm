# 🐒 Bombanana

Plugin Minecraft **Paper 1.21.x** untuk game co-op 3 pemain: jinakkan bom bersama-sama, tapi masing-masing pemain punya keterbatasan. Terinspirasi game Steam **BOMBANANA!** (Lefto Studio).

> Proyek fan-made, tidak berafiliasi dengan Lefto Studio. Tidak ada aset dari game aslinya yang dipakai.

## Konsep

Tiga pemain mendapat peran acak:

| Peran | Kemampuan | Keterbatasan |
|-------|-----------|--------------|
| 🙈 **Monyet Buta** | Satu-satunya yang bisa menekan tombol bom | Tidak bisa melihat lampu dan layar timer |
| 🙉 **Monyet Tuli** | Bisa melihat lampu dan timer | Tidak bisa mendengar voice chat maupun suara bom |
| 🙊 **Monyet Bisu** | Memegang buku manual dan bisa mendengar semua orang | Tidak bisa bicara (voice maupun chat), hanya bisa memberi isyarat |

Alur komunikasinya: Tuli melihat lampu lalu menyebutkan warna, Bisu membuka buku manual lalu memberi isyarat, dan Buta menekan tombol sesuai petunjuk. Kalau salah, strike bertambah dan tabel di manual ikut berganti. Kalau strike habis atau waktu habis, bom meledak.

## Modul bom

- ✅ **Ritme/Simon**: lampu pusat berkedip, tekan tombol (atas/kanan/bawah/kiri) sesuai tabel warna ke posisi di buku manual.
- 🔜 Kabel, Tombol, Simbol, Tuas (lihat Roadmap).

## Kebutuhan

- Server **Paper 1.21.11** (atau yang kompatibel)
- **Java 21**
- [Simple Voice Chat](https://modrinth.com/plugin/simple-voice-chat) (soft dependency; tanpa ini aturan suara tidak aktif)

## Instalasi

1. Unduh `Bombanana-x.y.z.jar` dari halaman **Releases** (atau dari artifact GitHub Actions).
2. Taruh di folder `plugins/` server.
3. Pastikan Simple Voice Chat sudah terpasang, lalu restart server.

## Cara main

```
/bombanana start <pemain1> <pemain2> <pemain3>
/bombanana stop
```

Bom muncul di lokasi pemegang command, dan ketiga pemain otomatis dipindahkan ke depannya. Permission: `bombanana.admin` (default: OP).

Sebaiknya mainkan di area atau dunia terpisah, karena suara pemain game dikirim sebagai static packet (tanpa efek jarak) dan pemain di luar game tidak ikut mendengar.

## Konfigurasi (`config.yml`)

```yaml
bomb:
  seconds: 180      # durasi timer bom
  max-strikes: 3    # batas kesalahan sebelum meledak
simon:
  stages: 3         # jumlah tahap modul Ritme/Simon
```

## Build

Butuh JDK 21 dan Maven.

```
mvn package
```

Hasilnya ada di `target/Bombanana-<versi>.jar`. Setiap push ke `main` otomatis di-build lewat GitHub Actions, dan tag berformat `v*` (misalnya `v0.1.0`) otomatis membuat GitHub Release berisi jar.

## Struktur

```
src/main/java/id/bombanana/BombananaPlugin.java   # semua kelas (digabung dalam satu file)
src/main/resources/plugin.yml
src/main/resources/config.yml
.github/workflows/build.yml
pom.xml
```

## Catatan teknis

- Bom dibuat dari Display entity (`BlockDisplay`, `TextDisplay`) dan klik ditangkap lewat entity `Interaction`.
- Elemen yang tidak boleh dilihat Buta disembunyikan per pemain dengan `Player#hideEntity`.
- Aturan suara memakai `MicrophonePacketEvent` dari Simple Voice Chat: paket dibatalkan lalu dikirim ulang hanya ke penerima yang diizinkan.
- Belum diuji di semua versi Paper dan Simple Voice Chat. Nama method SVC API dan `Interaction#setResponsive` mungkin perlu disesuaikan.

## Roadmap

- [ ] Modul Kabel
- [ ] Modul Tombol
- [ ] Modul Simbol
- [ ] Modul Tuas
- [ ] Beberapa modul sekaligus dalam satu bom (tata letak otomatis)
- [ ] File bahasa dan pesan yang bisa diatur
- [ ] Mode arena dengan pembatasan area

## Lisensi

Belum ditentukan. Tambahkan file `LICENSE` sebelum dipublikasikan (misalnya MIT).
