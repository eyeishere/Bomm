package id.bombanana;

import de.maxhenkel.voicechat.api.BukkitVoicechatService;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import de.maxhenkel.voicechat.api.packets.MicrophonePacket;
import io.papermc.paper.event.player.AsyncChatEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

public class BombananaPlugin extends JavaPlugin {

    private BombGame game;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        game = new BombGame(this);

        getServer().getPluginManager().registerEvents(game, this);
        getServer().getPluginManager().registerEvents(new BombClickListener(game::activeModules), this);

        if (getServer().getPluginManager().getPlugin("voicechat") != null) {
            hookVoicechat();
        } else {
            getLogger().warning("Simple Voice Chat tidak ditemukan, aturan suara tidak aktif.");
        }
    }

    /** Dipisah supaya class SVC baru dimuat kalau pluginnya benar-benar ada. */
    private void hookVoicechat() {
        BukkitVoicechatService svc = getServer().getServicesManager().load(BukkitVoicechatService.class);
        if (svc != null) {
            svc.registerPlugin(new VoiceHook(game));
            getLogger().info("Simple Voice Chat terhubung.");
        } else {
            getLogger().warning("Layanan Simple Voice Chat belum tersedia, aturan suara tidak aktif.");
        }
    }

    @Override
    public void onDisable() {
        if (game != null) game.stop();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) return false;

        if (args[0].equalsIgnoreCase("stop")) {
            game.stop();
            sender.sendMessage("Game dihentikan.");
            return true;
        }

        if (!args[0].equalsIgnoreCase("start")) return false;

        if (!(sender instanceof Player host)) {
            sender.sendMessage("Command ini hanya bisa dipakai pemain (lokasi dipakai sebagai posisi bom).");
            return true;
        }
        if (args.length != 4) {
            sender.sendMessage("Pakai: /bombanana start <pemain1> <pemain2> <pemain3>");
            return true;
        }
        if (game.isRunning()) {
            sender.sendMessage("Game masih berjalan. Pakai /bombanana stop dulu.");
            return true;
        }

        List<Player> participants = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            Player p = Bukkit.getPlayerExact(args[i]);
            if (p == null || participants.contains(p)) {
                sender.sendMessage("Pemain tidak ditemukan atau dobel: " + args[i]);
                return true;
            }
            participants.add(p);
        }

        // Pusat bom setinggi dada di depan host; pemain berdiri 3 blok di sisi +Z menghadap utara.
        Location origin = host.getLocation().getBlock().getLocation().add(0.5, 1.3, 0.5);
        for (int i = 0; i < 3; i++) {
            Location spot = origin.clone().add(i - 1, -1.3, 3);
            spot.setYaw(180f);
            spot.setPitch(0f);
            participants.get(i).teleport(spot);
        }

        if (!game.start(participants, origin)) {
            sender.sendMessage("Gagal memulai game.");
        }
        return true;
    }

    // =====================================================================
    // Kelas-kelas pendukung (digabung ke satu file)
    // =====================================================================

    public enum Role {
        BLIND("Monyet Buta"),
        DEAF("Monyet Tuli"),
        MUTE("Monyet Bisu");

        public final String label;

        Role(String label) {
            this.label = label;
        }
    }

    /** Kontrak yang harus dipenuhi setiap modul bom (Kabel, Tombol, Simon, dst). */
    public interface BombModule {

        /** Munculkan semua entity modul di sekitar origin. */
        void spawn(Location origin);

        /** Mulai modul (dipanggil saat ronde dimulai). */
        void start();

        /**
         * Tangani klik pemain pada entity.
         * @return true kalau entity itu milik modul ini (event boleh di-cancel)
         */
        boolean handleClick(Player player, Entity clicked);

        boolean isSolved();

        /** Halaman buku manual untuk modul ini (dibaca Mute Monkey). */
        List<Component> manualPages();

        /** Hentikan task dan hapus semua entity. */
        void cleanup();
    }

    /** Satu bom: memegang timer, strike, dan daftar modul. */
    public static class Bomb {

        public enum Result { DEFUSED, EXPLODED }

        private final JavaPlugin plugin;
        private final int maxStrikes;
        private final Consumer<Result> onEnd;
        private final List<BombModule> modules = new ArrayList<>();

        private int secondsLeft;
        private int strikes;
        private boolean ended;
        private Location origin;
        private TextDisplay display;
        private BukkitTask timer;
        private Player deaf;

        public Bomb(JavaPlugin plugin, int seconds, int maxStrikes, Consumer<Result> onEnd) {
            this.plugin = plugin;
            this.secondsLeft = seconds;
            this.maxStrikes = maxStrikes;
            this.onEnd = onEnd;
        }

        public void addModule(BombModule module) {
            modules.add(module);
        }

        public List<BombModule> modules() {
            return modules;
        }

        public int getStrikes() {
            return strikes;
        }

        /** Munculkan layar timer + semua modul. Layar disembunyikan dari Blind. */
        public void spawn(Location origin, Player blind) {
            this.origin = origin;
            display = origin.getWorld().spawn(origin.clone().add(0, 2.6, 0), TextDisplay.class, d -> {
                d.setBillboard(Display.Billboard.CENTER);
                d.setPersistent(false);
            });
            blind.hideEntity(plugin, display);

            for (BombModule m : modules) {
                m.spawn(origin); // TODO: kalau modul > 1, beri offset posisi tiap modul
            }
            refreshDisplay();
        }

        public void start() {
            for (BombModule m : modules) m.start();

            timer = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
                secondsLeft--;
                if (secondsLeft <= 0) {
                    explode();
                    return;
                }
                refreshDisplay();
                if (secondsLeft <= 10) {
                    play(Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1.5f);
                }
            }, 20L, 20L);
        }

        /** Dipanggil modul saat pemain salah. */
        public void strike() {
            if (ended) return;
            strikes++;
            play(Sound.ENTITY_VILLAGER_NO, 1f, 0.8f);
            refreshDisplay();
            if (strikes >= maxStrikes) explode();
        }

        /** Dipanggil modul saat selesai. Bom jinak kalau semua modul solved. */
        public void onModuleSolved() {
            if (ended) return;
            play(Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
            for (BombModule m : modules) {
                if (!m.isSolved()) return;
            }
            finish(Result.DEFUSED);
        }

        private void explode() {
            if (ended) return;
            origin.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, origin, 1);
            play(Sound.ENTITY_GENERIC_EXPLODE, 2f, 1f);
            finish(Result.EXPLODED);
        }

        private void finish(Result result) {
            ended = true;
            if (timer != null) timer.cancel();
            onEnd.accept(result);
        }

        /** Dipanggil BombGame: Monyet Tuli tidak mendengar suara bom. */
        public void setDeaf(Player deaf) {
            this.deaf = deaf;
        }

        private void play(Sound sound, float volume, float pitch) {
            for (Player p : origin.getWorld().getNearbyPlayers(origin, 48)) {
                if (!p.equals(deaf)) p.playSound(origin, sound, volume, pitch);
            }
        }

        private void refreshDisplay() {
            String time = String.format("%02d:%02d", secondsLeft / 60, secondsLeft % 60);
            Component strikeBar = Component.text("\u2716".repeat(strikes), NamedTextColor.RED)
                    .append(Component.text("\u25CB".repeat(Math.max(0, maxStrikes - strikes)), NamedTextColor.GRAY));
            display.text(Component.text(time, secondsLeft <= 30 ? NamedTextColor.RED : NamedTextColor.GREEN)
                    .append(Component.text("  "))
                    .append(strikeBar));
        }

        public void cleanup() {
            if (timer != null) timer.cancel();
            for (BombModule m : modules) m.cleanup();
            modules.clear();
            if (display != null && display.isValid()) display.remove();
        }
    }

    /** Mengatur satu sesi game: peran, bom, item, dan hasil akhir. */
    public static class BombGame implements Listener {

        /** Isyarat Mute di hotbar slot 1..6 (slot 0 = buku manual). */
        private static final String[] GESTURES = {"ATAS", "KANAN", "BAWAH", "KIRI", "YA", "TIDAK"};

        private final JavaPlugin plugin;
        private final Map<UUID, Role> roles = new ConcurrentHashMap<>();
        private final Map<Role, Player> players = new ConcurrentHashMap<>();
        private Bomb bomb;
        private volatile boolean running;

        public BombGame(JavaPlugin plugin) {
            this.plugin = plugin;
        }

        // ---------- Query (dipakai VoiceHook & listener) ----------

        public boolean isRunning() {
            return running;
        }

        public Role roleOf(UUID id) {
            return roles.get(id);
        }

        public Player playerOf(Role role) {
            return players.get(role);
        }

        public Collection<BombModule> activeModules() {
            return bomb == null ? List.of() : bomb.modules();
        }

        // ---------- Start / stop ----------

        public boolean start(List<Player> participants, Location origin) {
            if (running || participants.size() != 3) return false;

            List<Role> pool = new ArrayList<>(List.of(Role.values()));
            Collections.shuffle(pool);
            for (int i = 0; i < 3; i++) {
                roles.put(participants.get(i).getUniqueId(), pool.get(i));
                players.put(pool.get(i), participants.get(i));
            }

            FileConfiguration cfg = plugin.getConfig();
            bomb = new Bomb(plugin, cfg.getInt("bomb.seconds", 180), cfg.getInt("bomb.max-strikes", 3), this::onBombEnd);

            SimonModule simon = new SimonModule(
                    plugin,
                    players.get(Role.BLIND),
                    List.of(players.get(Role.DEAF), players.get(Role.MUTE)),
                    System.nanoTime(),
                    cfg.getInt("simon.stages", 3),
                    bomb::getStrikes,
                    bomb::strike,
                    bomb::onModuleSolved);
            bomb.addModule(simon);
            bomb.setDeaf(players.get(Role.DEAF));
            bomb.spawn(origin, players.get(Role.BLIND));

            giveMuteItems(simon);
            announceRoles();

            running = true;
            bomb.start();
            return true;
        }

        public void stop() {
            if (!running && bomb == null) return;
            running = false;

            Player mute = players.get(Role.MUTE);
            if (mute != null && mute.isOnline()) {
                for (int i = 0; i <= GESTURES.length; i++) mute.getInventory().setItem(i, null);
            }
            if (bomb != null) bomb.cleanup();
            bomb = null;
            roles.clear();
            players.clear();
        }

        private void onBombEnd(Bomb.Result result) {
            boolean win = result == Bomb.Result.DEFUSED;
            Title title = Title.title(
                    Component.text(win ? "BOM JINAK!" : "BOOM!", win ? NamedTextColor.GREEN : NamedTextColor.RED),
                    Component.text(win ? "Kerja sama kalian luar biasa" : "Bom meledak..."),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(500)));
            for (Player p : players.values()) p.showTitle(title);
            Bukkit.getScheduler().runTaskLater(plugin, this::stop, 80L);
        }

        // ---------- Item & pengumuman ----------

        private void giveMuteItems(SimonModule simon) {
            Player mute = players.get(Role.MUTE);

            ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
            BookMeta meta = (BookMeta) book.getItemMeta();
            meta.title(Component.text("Manual Bom"));
            meta.author(Component.text("Bombanana"));
            meta.addPages(simon.manualPages().toArray(new Component[0]));
            book.setItemMeta(meta);
            mute.getInventory().setItem(0, book);

            for (int i = 0; i < GESTURES.length; i++) {
                ItemStack item = new ItemStack(Material.FEATHER);
                ItemMeta im = item.getItemMeta();
                im.displayName(Component.text("Isyarat: " + GESTURES[i], NamedTextColor.YELLOW));
                item.setItemMeta(im);
                mute.getInventory().setItem(i + 1, item);
            }
            mute.getInventory().setHeldItemSlot(0);
        }

        private void announceRoles() {
            for (Map.Entry<Role, Player> e : players.entrySet()) {
                Role role = e.getKey();
                String hint = switch (role) {
                    case BLIND -> "Kamu tidak bisa melihat lampu. Kamu yang menekan tombol!";
                    case DEAF -> "Kamu tidak bisa mendengar. Lihat lampu dan sebutkan warnanya!";
                    case MUTE -> "Kamu tidak bisa bicara. Baca buku manual dan beri isyarat!";
                };
                e.getValue().showTitle(Title.title(
                        Component.text(role.label, NamedTextColor.GOLD),
                        Component.text(hint)));
            }
        }

        // ---------- Listener ----------

        /** Mute klik kanan item bulu -> kirim isyarat ke Deaf. */
        @EventHandler
        public void onGesture(PlayerInteractEvent e) {
            if (!running) return;
            if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
            if (roles.get(e.getPlayer().getUniqueId()) != Role.MUTE) return;

            int slot = e.getPlayer().getInventory().getHeldItemSlot();
            if (slot < 1 || slot > GESTURES.length) return;
            e.setCancelled(true);

            Player deaf = players.get(Role.DEAF);
            if (deaf != null) {
                deaf.sendActionBar(Component.text("Monyet Bisu memberi isyarat: " + GESTURES[slot - 1], NamedTextColor.YELLOW));
            }
        }

        /** Monyet Bisu tidak boleh bicara lewat chat teks juga. */
        @EventHandler
        public void onChat(AsyncChatEvent e) {
            if (running && roles.get(e.getPlayer().getUniqueId()) == Role.MUTE) {
                e.setCancelled(true);
                e.getPlayer().sendMessage(Component.text("Kamu bisu! Pakai isyarat bulu.", NamedTextColor.RED));
            }
        }

        @EventHandler
        public void onDrop(PlayerDropItemEvent e) {
            if (running && roles.containsKey(e.getPlayer().getUniqueId())) e.setCancelled(true);
        }

        @EventHandler
        public void onInventoryClick(InventoryClickEvent e) {
            if (running && roles.containsKey(e.getWhoClicked().getUniqueId())) e.setCancelled(true);
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent e) {
            if (running && roles.containsKey(e.getPlayer().getUniqueId())) {
                for (Player p : players.values()) {
                    if (p.isOnline()) p.sendMessage(Component.text("Ada pemain keluar, game dihentikan.", NamedTextColor.RED));
                }
                stop();
            }
        }
    }

    /**
     * Modul Ritme/Simon.
     *
     * - Lampu pusat berkedip (hanya terlihat oleh yang BUKAN Blind).
     * - 4 tombol netral di posisi Atas/Kanan/Bawah/Kiri (sama untuk semua pemain).
     * - Manual (buku) memetakan warna -> posisi tombol, tabelnya tergantung jumlah strike bom.
     * - Hanya Blind Monkey yang boleh menekan tombol.
     */
    public static class SimonModule implements BombModule {

        // ===== Konstanta (pindahkan ke config.yml nanti) =====
        private static final int START_DELAY_TICKS = 20;
        private static final int FLASH_TICKS = 12;     // ~600 ms
        private static final int GAP_TICKS = 6;        // ~300 ms
        private static final int TIMEOUT_TICKS = 140;  // 7 detik tanpa input -> putar ulang
        private static final int RETRY_DELAY_TICKS = 20;
        private static final int MAX_TABLE = 2;        // tabel manual untuk strike 0, 1, 2+

        public enum Color {
            RED(Material.RED_CONCRETE, "Merah"),
            BLUE(Material.BLUE_CONCRETE, "Biru"),
            GREEN(Material.LIME_CONCRETE, "Hijau"),
            YELLOW(Material.YELLOW_CONCRETE, "Kuning");

            final Material material;
            final String label;

            Color(Material material, String label) {
                this.material = material;
                this.label = label;
            }
        }

        public enum Pos {
            UP("Atas", 0, 0.9),
            RIGHT("Kanan", 0.9, 0),
            DOWN("Bawah", 0, -0.9),
            LEFT("Kiri", -0.9, 0);

            final String label;
            final double dx; // offset horizontal (sumbu X, ubah kalau bom menghadap arah lain)
            final double dy; // offset vertikal

            Pos(String label, double dx, double dy) {
                this.label = label;
                this.dx = dx;
                this.dy = dy;
            }
        }

        private enum State { IDLE, PLAYING, WAITING_INPUT, SOLVED }

        // ===== Dependensi dari Bomb =====
        private final JavaPlugin plugin;
        private final Player blind;
        private final List<Player> others; // Deaf + Mute (yang boleh lihat lampu)
        private final int totalStages;
        private final IntSupplier bombStrikes;
        private final Runnable onStrike;
        private final Runnable onSolved;

        // ===== Data ronde =====
        private final List<Color> sequence = new ArrayList<>();
        private final Map<Integer, Map<Color, Pos>> tables = new HashMap<>();

        // ===== Entity =====
        private BlockDisplay lamp;
        private final Map<UUID, Pos> buttonByEntity = new HashMap<>();
        private final List<Entity> spawned = new ArrayList<>();

        // ===== State =====
        private State state = State.IDLE;
        private int stage = 1;       // panjang urutan yang sedang ditampilkan
        private int inputIndex = 0;
        private final List<BukkitTask> tasks = new ArrayList<>();
        private BukkitTask timeoutTask;

        public SimonModule(JavaPlugin plugin, Player blind, List<Player> others, long seed,
                           int totalStages, IntSupplier bombStrikes,
                           Runnable onStrike, Runnable onSolved) {
            this.plugin = plugin;
            this.blind = blind;
            this.others = others;
            this.totalStages = totalStages;
            this.bombStrikes = bombStrikes;
            this.onStrike = onStrike;
            this.onSolved = onSolved;
            generate(new Random(seed));
        }

        // ---------- Generate aturan ronde ----------

        private void generate(Random rnd) {
            for (int i = 0; i < totalStages; i++) {
                sequence.add(Color.values()[rnd.nextInt(Color.values().length)]);
            }
            for (int s = 0; s <= MAX_TABLE; s++) {
                List<Pos> shuffled = new ArrayList<>(List.of(Pos.values()));
                Collections.shuffle(shuffled, rnd);
                Map<Color, Pos> map = new EnumMap<>(Color.class);
                for (Color c : Color.values()) {
                    map.put(c, shuffled.get(c.ordinal()));
                }
                tables.put(s, map);
            }
        }

        // ---------- Spawn ----------

        @Override
        public void spawn(Location origin) {
            World w = origin.getWorld();

            lamp = cube(origin.clone().add(0, 1.6, 0), Material.BLACK_CONCRETE, 0.6f);
            blind.hideEntity(plugin, lamp); // Blind tidak bisa melihat lampu
            spawned.add(lamp);

            for (Pos pos : Pos.values()) {
                Location loc = origin.clone().add(pos.dx, pos.dy, 0);
                spawned.add(cube(loc, Material.GRAY_CONCRETE, 0.5f));

                Interaction hit = w.spawn(loc.clone().add(0, -0.35, 0), Interaction.class, i -> {
                    i.setInteractionWidth(0.7f);
                    i.setInteractionHeight(0.7f);
                    i.setResponsive(true); // cek ketersediaan di versi Paper kamu
                    i.setPersistent(false);
                });
                buttonByEntity.put(hit.getUniqueId(), pos);
                spawned.add(hit);
            }
        }

        private BlockDisplay cube(Location loc, Material mat, float size) {
            return loc.getWorld().spawn(loc, BlockDisplay.class, d -> {
                d.setBlock(mat.createBlockData());
                d.setTransformation(new Transformation(
                        new Vector3f(-size / 2, -size / 2, -size / 2),
                        new AxisAngle4f(),
                        new Vector3f(size, size, size),
                        new AxisAngle4f()));
                d.setPersistent(false);
            });
        }

        // ---------- Alur permainan ----------

        @Override
        public void start() {
            stage = 1;
            playSequence();
        }

        private void playSequence() {
            cancelTasks();
            state = State.PLAYING;
            inputIndex = 0;

            long t = START_DELAY_TICKS;
            for (Color c : sequence.subList(0, stage)) {
                schedule(t, () -> lampOn(c));
                t += FLASH_TICKS;
                schedule(t, this::lampOff);
                t += GAP_TICKS;
            }
            schedule(t, () -> {
                state = State.WAITING_INPUT;
                armTimeout();
            });
        }

        private void lampOn(Color c) {
            lamp.setBlock(c.material.createBlockData());
            lamp.setBrightness(new Display.Brightness(15, 15));
        }

        private void lampOff() {
            lamp.setBlock(Material.BLACK_CONCRETE.createBlockData());
            lamp.setBrightness(null);
        }

        @Override
        public boolean handleClick(Player player, Entity clicked) {
            Pos pressed = buttonByEntity.get(clicked.getUniqueId());
            if (pressed == null) return false; // bukan entity modul ini
            if (state != State.WAITING_INPUT) return true;

            if (!player.getUniqueId().equals(blind.getUniqueId())) {
                player.sendActionBar(Component.text("Hanya Blind Monkey yang bisa menekan tombol ini!"));
                return true;
            }

            Location loc = clicked.getLocation();
            loc.getWorld().playSound(loc, Sound.UI_BUTTON_CLICK, 1f, 1f); // satu suara sama utk semua tombol

            int tableIndex = Math.min(bombStrikes.getAsInt(), MAX_TABLE);
            Pos expected = tables.get(tableIndex).get(sequence.get(inputIndex));

            if (pressed != expected) {
                onStrike.run(); // Bomb yang menambah strike / meledakkan
                schedule(RETRY_DELAY_TICKS, this::playSequence);
                state = State.PLAYING;
                return true;
            }

            inputIndex++;
            armTimeout();

            if (inputIndex >= stage) {
                stage++;
                if (stage > totalStages) {
                    state = State.SOLVED;
                    cancelTasks();
                    onSolved.run();
                } else {
                    state = State.PLAYING;
                    schedule(RETRY_DELAY_TICKS, this::playSequence);
                }
            }
            return true;
        }

        // ---------- Manual ----------

        @Override
        public List<Component> manualPages() {
            List<Component> pages = new ArrayList<>();
            for (int s = 0; s <= MAX_TABLE; s++) {
                StringBuilder sb = new StringBuilder();
                sb.append(s == 0 ? "RITME\nLampu berkedip -> tekan tombol\n\n" : "RITME (lanjutan)\n\n");
                sb.append(s == MAX_TABLE ? "Strike " + s + " atau lebih:\n" : "Strike " + s + ":\n");
                for (Color c : Color.values()) {
                    sb.append(c.label).append(" > ").append(tables.get(s).get(c).label).append("\n");
                }
                pages.add(Component.text(sb.toString()));
            }
            return pages;
        }

        // ---------- Util ----------

        @Override
        public boolean isSolved() {
            return state == State.SOLVED;
        }

        private void schedule(long delay, Runnable r) {
            tasks.add(Bukkit.getScheduler().runTaskLater(plugin, r, delay));
        }

        private void armTimeout() {
            if (timeoutTask != null) timeoutTask.cancel();
            timeoutTask = Bukkit.getScheduler().runTaskLater(plugin, this::playSequence, TIMEOUT_TICKS);
        }

        private void cancelTasks() {
            for (BukkitTask t : tasks) t.cancel();
            tasks.clear();
            if (timeoutTask != null) {
                timeoutTask.cancel();
                timeoutTask = null;
            }
        }

        @Override
        public void cleanup() {
            cancelTasks();
            for (Entity e : spawned) {
                if (e.isValid()) e.remove();
            }
            spawned.clear();
            buttonByEntity.clear();
        }
    }

    /** Meneruskan klik kiri/kanan pada Interaction entity ke modul bom yang aktif. */
    public static class BombClickListener implements Listener {

        private final Supplier<Collection<BombModule>> activeModules;

        public BombClickListener(Supplier<Collection<BombModule>> activeModules) {
            this.activeModules = activeModules;
        }

        @EventHandler
        public void onRightClick(PlayerInteractEntityEvent e) {
            if (route(e.getPlayer(), e.getRightClicked())) e.setCancelled(true);
        }

        @EventHandler
        public void onLeftClick(EntityDamageByEntityEvent e) {
            if (!(e.getDamager() instanceof Player player)) return;
            if (route(player, e.getEntity())) e.setCancelled(true);
        }

        private boolean route(Player player, Entity clicked) {
            if (!(clicked instanceof Interaction)) return false;
            for (BombModule module : activeModules.get()) {
                if (module.handleClick(player, clicked)) return true;
            }
            return false;
        }
    }

    /**
     * Aturan suara:
     * - MUTE : suaranya dibuang (tidak didengar siapa pun).
     * - BLIND: hanya didengar MUTE (DEAF tidak bisa mendengar).
     * - DEAF : didengar BLIND dan MUTE.
     *
     * Semua suara pemain game dibatalkan lalu dikirim ulang ke penerima yang diizinkan.
     * Catatan: suara dikirim sebagai static packet (tanpa efek jarak). Pemain di luar game
     * tidak disentuh, jadi sebaiknya game dimainkan di area/dunia yang terpisah.
     */
    public static class VoiceHook implements VoicechatPlugin {

        private final BombGame game;

        public VoiceHook(BombGame game) {
            this.game = game;
        }

        @Override
        public String getPluginId() {
            return "bombanana";
        }

        @Override
        public void initialize(VoicechatApi api) {
            // tidak ada inisialisasi khusus
        }

        @Override
        public void registerEvents(EventRegistration registration) {
            registration.registerEvent(MicrophonePacketEvent.class, this::onMicrophone);
        }

        private void onMicrophone(MicrophonePacketEvent event) {
            if (!game.isRunning()) return;

            VoicechatConnection senderConn = event.getSenderConnection();
            if (senderConn == null) return;
            if (!(senderConn.getPlayer().getPlayer() instanceof Player sender)) return;

            Role role = game.roleOf(sender.getUniqueId());
            if (role == null) return; // bukan peserta game

            event.cancel(); // hentikan penerusan proximity bawaan SVC
            if (role == Role.MUTE) return;

            List<Role> listeners = (role == Role.BLIND)
                    ? List.of(Role.MUTE)
                    : List.of(Role.BLIND, Role.MUTE);

            VoicechatServerApi api = event.getVoicechat();
            MicrophonePacket packet = event.getPacket();

            for (Role target : listeners) {
                Player p = game.playerOf(target);
                if (p == null) continue;
                VoicechatConnection conn = api.getConnectionOf(p.getUniqueId());
                if (conn == null) continue;
                api.sendStaticSoundPacketTo(conn, packet.staticSoundPacketBuilder().build());
            }
        }
    }
}
